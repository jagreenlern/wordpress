 # Do Not Put Custom Translations Here
  
 Do not put custom translations here. They will be deleted on Give updates. Keep your custom Give translations in `WP_LANG_DIR . "/give/{$textdomain}-{$locale}.mo";`
  
  ## Translating Give
  
  If you would like to translate, help, or improve a translation we'd love your help! Please join the our [translation page](https://translate.wordpress.org/projects/wp-plugins/give).

