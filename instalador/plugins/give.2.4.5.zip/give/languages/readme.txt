********************************************************

  Give i18n
  ============================
  
  Do not put custom translations here. They will be deleted
  on Give updates.

  Keep custom Give translations in /wp-content/languages/give/

  If you would like to translate, help, or improve a translation.

  Email info@wordmpress.com OR join the GlotPress community:
  https://translate.wordpress.org/projects/wp-plugins/give

********************************************************